
SCRIPT ENTER (MissingExceptionalReject2.js:1:1:19:1) MissingExceptionalReject2_jalangi_.js MissingExceptionalReject2.js
*** call to Promise() constructor at (MissingExceptionalReject2.js:2:10:4:3) creates promise p0
*** promise p0 RESOLVED with value 42 at (MissingExceptionalReject2.js:3:5:3:16)
*** return from call to Promise() constructor at (MissingExceptionalReject2.js:2:10:4:3) associates OID obj3 with promise p0
*** resolve identity  registered at (MissingExceptionalReject2.js:5:1:6:3) on p0
*** reject identity _default registered at (MissingExceptionalReject2.js:5:1:6:3) on p0
*** call to then() on promise p0 at (MissingExceptionalReject2.js:5:1:6:3) creates promise p1
*** resolve identity  registered at (MissingExceptionalReject2.js:5:1:7:3) on p1
*** reject identity _default registered at (MissingExceptionalReject2.js:5:1:7:3) on p1
*** call to then() on promise p1 at (MissingExceptionalReject2.js:5:1:7:3) creates promise p2
*** call to Promise() constructor at (MissingExceptionalReject2.js:11:10:13:3) creates promise p3
*** promise p3 RESOLVED with value 42 at (MissingExceptionalReject2.js:12:5:12:16)
*** return from call to Promise() constructor at (MissingExceptionalReject2.js:11:10:13:3) associates OID obj17 with promise p3
*** resolve identity  registered at (MissingExceptionalReject2.js:14:1:16:3) on p3
*** reject identity _default registered at (MissingExceptionalReject2.js:14:1:16:3) on p3
*** call to then() on promise p3 at (MissingExceptionalReject2.js:14:1:16:3) creates promise p4
*** resolve identity  registered at (MissingExceptionalReject2.js:14:1:18:3) on p4
*** reject identity _default registered at (MissingExceptionalReject2.js:14:1:18:3) on p4
*** call to then() on promise p4 at (MissingExceptionalReject2.js:14:1:18:3) creates promise p5
SCRIPT EXIT (MissingExceptionalReject2.js:1:1:19:1)
*** function  returned value undefined at (MissingExceptionalReject2.js:5:1:6:3)
*** promise p1 RESOLVED with implicitly returned value undefined at (MissingExceptionalReject2.js:5:1:6:3)
*** function  returned value undefined at (MissingExceptionalReject2.js:14:1:16:3)
*** promise p4 RESOLVED with implicitly returned value undefined at (MissingExceptionalReject2.js:14:1:16:3)
*** function  returned value undefined at (MissingExceptionalReject2.js:5:1:7:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (MissingExceptionalReject2.js:5:1:7:3)
*** function  returned value undefined at (MissingExceptionalReject2.js:14:1:18:3)
*** promise p5 RESOLVED with implicitly returned value undefined at (MissingExceptionalReject2.js:14:1:18:3)
** endExecution for unit-test
