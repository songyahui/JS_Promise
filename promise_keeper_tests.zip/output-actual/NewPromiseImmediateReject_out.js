
SCRIPT ENTER (NewPromiseImmediateReject.js:1:1:3:63) NewPromiseImmediateReject_jalangi_.js NewPromiseImmediateReject.js
*** call to Promise() constructor at (NewPromiseImmediateReject.js:3:9:3:62) creates promise p0
*** promise p0 REJECTED with value 42 at (NewPromiseImmediateReject.js:3:49:3:59)
*** return from call to Promise() constructor at (NewPromiseImmediateReject.js:3:9:3:62) associates OID obj3 with promise p0
SCRIPT EXIT (NewPromiseImmediateReject.js:1:1:3:63)
** endExecution for unit-test
