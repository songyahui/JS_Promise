
SCRIPT ENTER (PromiseReturnArrReject.js:1:1:5:64) PromiseReturnArrReject_jalangi_.js PromiseReturnArrReject.js
*** call to Promise() constructor at (PromiseReturnArrReject.js:5:9:5:63) creates promise p0
*** promise p0 REJECTED with value 0,1,2 at (PromiseReturnArrReject.js:5:49:5:60)
*** return from call to Promise() constructor at (PromiseReturnArrReject.js:5:9:5:63) associates OID obj5 with promise p0
SCRIPT EXIT (PromiseReturnArrReject.js:1:1:5:64)
** endExecution for unit-test
