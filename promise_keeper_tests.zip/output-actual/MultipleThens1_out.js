
SCRIPT ENTER (MultipleThens1.js:1:1:7:4) MultipleThens1_jalangi_.js MultipleThens1.js
*** call to Promise.resolve() at (MultipleThens1.js:1:9:1:29) creates promise p0
*** return from call to Promise.resolve() at (MultipleThens1.js:1:9:1:29) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value a at (MultipleThens1.js:1:9:1:29)
*** resolve identity  registered at (MultipleThens1.js:2:1:4:3) on p0
*** reject identity _default registered at (MultipleThens1.js:2:1:4:3) on p0
*** call to then() on promise p0 at (MultipleThens1.js:2:1:4:3) creates promise p1
*** resolve identity  registered at (MultipleThens1.js:5:1:7:3) on p0
*** reject identity _default registered at (MultipleThens1.js:5:1:7:3) on p0
*** call to then() on promise p0 at (MultipleThens1.js:5:1:7:3) creates promise p2
SCRIPT EXIT (MultipleThens1.js:1:1:7:4)
*** function  returned value b at (MultipleThens1.js:2:1:4:3)
*** promise p1 RESOLVED with explicitly returned value b at (MultipleThens1.js:2:1:4:3)
*** function  returned value undefined at (MultipleThens1.js:5:1:7:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (MultipleThens1.js:5:1:7:3)
** endExecution for unit-test
