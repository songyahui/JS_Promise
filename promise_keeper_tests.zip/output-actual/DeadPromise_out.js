
SCRIPT ENTER (DeadPromise.js:1:1:8:1) DeadPromise_jalangi_.js DeadPromise.js
*** call to Promise() constructor at (DeadPromise.js:3:9:6:3) creates promise p0
*** return from call to Promise() constructor at (DeadPromise.js:3:9:6:3) associates OID obj3 with promise p0
*** resolve identity  registered at (DeadPromise.js:7:1:7:38) on p0
*** reject identity _default registered at (DeadPromise.js:7:1:7:38) on p0
*** call to then() on promise p0 at (DeadPromise.js:7:1:7:38) creates promise p1
SCRIPT EXIT (DeadPromise.js:1:1:8:1)
** endExecution for unit-test
