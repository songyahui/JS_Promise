
SCRIPT ENTER (LinkedByResolve.js:1:1:6:1) LinkedByResolve_jalangi_.js LinkedByResolve.js
*** call to Promise.resolve() at (LinkedByResolve.js:1:10:1:29) creates promise p0
*** return from call to Promise.resolve() at (LinkedByResolve.js:1:10:1:29) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 17 at (LinkedByResolve.js:1:10:1:29)
*** call to Promise() constructor at (LinkedByResolve.js:2:10:4:3) creates promise p1
*** promise p1 RESOLVED with value [object Promise] at (LinkedByResolve.js:3:5:3:16)
*** return from call to Promise() constructor at (LinkedByResolve.js:2:10:4:3) associates OID obj5 with promise p1
*** resolve identity  registered at (LinkedByResolve.js:5:1:5:40) on p1
*** reject identity _default registered at (LinkedByResolve.js:5:1:5:40) on p1
*** call to then() on promise p1 at (LinkedByResolve.js:5:1:5:40) creates promise p2
SCRIPT EXIT (LinkedByResolve.js:1:1:6:1)
*** function  returned value undefined at (LinkedByResolve.js:5:1:5:40)
*** promise p2 RESOLVED with implicitly returned value undefined at (LinkedByResolve.js:5:1:5:40)
** endExecution for unit-test
