
SCRIPT ENTER (MissingResolveOrReject.js:1:1:8:1) MissingResolveOrReject_jalangi_.js MissingResolveOrReject.js
*** call to Promise() constructor at (MissingResolveOrReject.js:3:9:6:3) creates promise p0
*** promise p0 RESOLVED with value 42 at (MissingResolveOrReject.js:5:5:5:16)
*** return from call to Promise() constructor at (MissingResolveOrReject.js:3:9:6:3) associates OID obj3 with promise p0
SCRIPT EXIT (MissingResolveOrReject.js:1:1:8:1)
** endExecution for unit-test
