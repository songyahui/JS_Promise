
SCRIPT ENTER (ReturnNewBluebirdPromiseThen.js:1:1:18:7) ReturnNewBluebirdPromiseThen_jalangi_.js ReturnNewBluebirdPromiseThen.js
*** call to Promise() constructor at (ReturnNewBluebirdPromiseThen.js:6:12:9:7) creates promise p0
*** promise p0 RESOLVED with value undefined at (ReturnNewBluebirdPromiseThen.js:8:9:8:18)
*** return from call to Promise() constructor at (ReturnNewBluebirdPromiseThen.js:6:12:9:7) associates OID obj3 with promise p0
*** resolve identity  registered at (ReturnNewBluebirdPromiseThen.js:13:12:15:7) on p0
*** reject identity _default registered at (ReturnNewBluebirdPromiseThen.js:13:12:15:7) on p0
*** call to then() on promise p0 at (ReturnNewBluebirdPromiseThen.js:13:12:15:7) creates promise p1
SCRIPT EXIT (ReturnNewBluebirdPromiseThen.js:1:1:18:7)
*** function  returned value undefined at (ReturnNewBluebirdPromiseThen.js:13:12:15:7)
*** promise p1 RESOLVED with implicitly returned value undefined at (ReturnNewBluebirdPromiseThen.js:13:12:15:7)
** endExecution for unit-test
