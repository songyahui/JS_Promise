
SCRIPT ENTER (NewPromiseResolveThen2.js:1:1:7:4) NewPromiseResolveThen2_jalangi_.js NewPromiseResolveThen2.js
*** call to Promise() constructor at (NewPromiseResolveThen2.js:3:9:3:66) creates promise p0
*** promise p0 RESOLVED with value 42 at (NewPromiseResolveThen2.js:3:51:3:62)
*** return from call to Promise() constructor at (NewPromiseResolveThen2.js:3:9:3:66) associates OID obj3 with promise p0
*** resolve identity f2 registered at (NewPromiseResolveThen2.js:4:10:7:3) on p0
*** reject identity _default registered at (NewPromiseResolveThen2.js:4:10:7:3) on p0
*** call to then() on promise p0 at (NewPromiseResolveThen2.js:4:10:7:3) creates promise p1
SCRIPT EXIT (NewPromiseResolveThen2.js:1:1:7:4)
*** function f2 returned value 84 at (NewPromiseResolveThen2.js:4:10:7:3)
*** promise p1 RESOLVED with explicitly returned value 84 at (NewPromiseResolveThen2.js:4:10:7:3)
** endExecution for unit-test
