
SCRIPT ENTER (NewPromiseResolveLater1.js:1:1:17:11) NewPromiseResolveLater1_jalangi_.js NewPromiseResolveLater1.js
*** call to Promise() constructor at (NewPromiseResolveLater1.js:6:10:6:66) creates promise p0
*** return from call to Promise() constructor at (NewPromiseResolveLater1.js:6:10:6:66) associates OID obj3 with promise p0
*** call to Promise() constructor at (NewPromiseResolveLater1.js:7:10:7:66) creates promise p1
*** return from call to Promise() constructor at (NewPromiseResolveLater1.js:7:10:7:66) associates OID obj5 with promise p1
*** resolve identity  registered at (NewPromiseResolveLater1.js:9:1:11:3) on p0
*** reject identity _default registered at (NewPromiseResolveLater1.js:9:1:11:3) on p0
*** call to then() on promise p0 at (NewPromiseResolveLater1.js:9:1:11:3) creates promise p2
*** resolve identity  registered at (NewPromiseResolveLater1.js:12:1:14:3) on p1
*** reject identity _default registered at (NewPromiseResolveLater1.js:12:1:14:3) on p1
*** call to then() on promise p1 at (NewPromiseResolveLater1.js:12:1:14:3) creates promise p3
*** promise p0 RESOLVED with value foo at (NewPromiseResolveLater1.js:16:1:16:10)
*** promise p1 RESOLVED with value bar at (NewPromiseResolveLater1.js:17:1:17:10)
SCRIPT EXIT (NewPromiseResolveLater1.js:1:1:17:11)
*** function  returned value undefined at (NewPromiseResolveLater1.js:9:1:11:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (NewPromiseResolveLater1.js:9:1:11:3)
*** function  returned value undefined at (NewPromiseResolveLater1.js:12:1:14:3)
*** promise p3 RESOLVED with implicitly returned value undefined at (NewPromiseResolveLater1.js:12:1:14:3)
** endExecution for unit-test
