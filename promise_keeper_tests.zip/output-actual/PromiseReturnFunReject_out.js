
SCRIPT ENTER (PromiseReturnFunReject.js:1:1:7:64) PromiseReturnFunReject_jalangi_.js PromiseReturnFunReject.js
*** call to Promise() constructor at (PromiseReturnFunReject.js:7:9:7:63) creates promise p0
*** promise p0 REJECTED with value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(201, J$e);
                        } finally {
                            if (J$.Fr(209))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (PromiseReturnFunReject.js:7:49:7:60)
*** return from call to Promise() constructor at (PromiseReturnFunReject.js:7:9:7:63) associates OID obj5 with promise p0
SCRIPT EXIT (PromiseReturnFunReject.js:1:1:7:64)
** endExecution for unit-test
