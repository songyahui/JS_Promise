
SCRIPT ENTER (AllSyncResolve.js:1:1:16:55) AllSyncResolve_jalangi_.js AllSyncResolve.js
*** call to all() on array [] at (AllSyncResolve.js:3:9:3:24) creates promise p0
*** call to all() on array [1337,"hi"] at (AllSyncResolve.js:4:10:4:35) creates promise p1
SCRIPT EXIT (AllSyncResolve.js:1:1:16:55)
** endExecution for unit-test
