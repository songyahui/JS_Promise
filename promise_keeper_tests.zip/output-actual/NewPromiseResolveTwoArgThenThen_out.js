
SCRIPT ENTER (NewPromiseResolveTwoArgThenThen.js:1:1:13:3) NewPromiseResolveTwoArgThenThen_jalangi_.js NewPromiseResolveTwoArgThenThen.js
*** call to Promise() constructor at (NewPromiseResolveTwoArgThenThen.js:3:9:3:63) creates promise p0
*** promise p0 RESOLVED with value 42 at (NewPromiseResolveTwoArgThenThen.js:3:49:3:60)
*** return from call to Promise() constructor at (NewPromiseResolveTwoArgThenThen.js:3:9:3:63) associates OID obj3 with promise p0
*** resolve identity f1 registered at (NewPromiseResolveTwoArgThenThen.js:4:10:10:3) on p0
*** reject identity f2 registered at (NewPromiseResolveTwoArgThenThen.js:4:10:10:3) on p0
*** call to then() on promise p0 at (NewPromiseResolveTwoArgThenThen.js:4:10:10:3) creates promise p1
*** resolve identity f3 registered at (NewPromiseResolveTwoArgThenThen.js:11:10:13:3) on p1
*** reject identity _default registered at (NewPromiseResolveTwoArgThenThen.js:11:10:13:3) on p1
*** call to then() on promise p1 at (NewPromiseResolveTwoArgThenThen.js:11:10:13:3) creates promise p2
SCRIPT EXIT (NewPromiseResolveTwoArgThenThen.js:1:1:13:3)
*** function f1 returned value 84 at (NewPromiseResolveTwoArgThenThen.js:4:10:10:3)
*** promise p1 RESOLVED with explicitly returned value 84 at (NewPromiseResolveTwoArgThenThen.js:4:10:10:3)
*** function f3 returned value undefined at (NewPromiseResolveTwoArgThenThen.js:11:10:13:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (NewPromiseResolveTwoArgThenThen.js:11:10:13:3)
** endExecution for unit-test
