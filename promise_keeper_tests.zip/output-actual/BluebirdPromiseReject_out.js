
SCRIPT ENTER (BluebirdPromiseReject.js:1:1:12:26) BluebirdPromiseReject_jalangi_.js BluebirdPromiseReject.js
*** call to Promise() constructor at (BluebirdPromiseReject.js:5:1:10:3) creates promise p0
*** promise p0 REJECTED with value Oh no!, An error occurred! at (BluebirdPromiseReject.js:7:12:7:48)
*** return from call to Promise() constructor at (BluebirdPromiseReject.js:5:1:10:3) associates OID obj3 with promise p0
*** resolve identity bound consoleCall registered at (BluebirdPromiseReject.js:5:1:11:19) on p0
*** reject identity _default registered at (BluebirdPromiseReject.js:5:1:11:19) on p0
*** call to then() on promise p0 at (BluebirdPromiseReject.js:5:1:11:19) creates promise p1
*** resolve identity _default registered at (BluebirdPromiseReject.js:5:1:12:26) on p1
*** reject identity bound consoleCall registered at (BluebirdPromiseReject.js:5:1:12:26) on p1
*** call to catch() on promise p1 at (BluebirdPromiseReject.js:5:1:12:26) creates promise p2
SCRIPT EXIT (BluebirdPromiseReject.js:1:1:12:26)
*** function _default returned value Oh no!, An error occurred! at (BluebirdPromiseReject.js:5:1:11:19)
*** promise p1 REJECTED with value Oh no!, An error occurred! at (BluebirdPromiseReject.js:5:1:11:19)
*** function bound consoleCall returned value undefined at (BluebirdPromiseReject.js:5:1:12:26)
*** promise p2 RESOLVED with explicitly returned value undefined at (BluebirdPromiseReject.js:5:1:12:26)
** endExecution for unit-test
