
SCRIPT ENTER (MultipleFulfillPrim1.js:1:1:9:4) MultipleFulfillPrim1_jalangi_.js MultipleFulfillPrim1.js
*** call to Promise() constructor at (MultipleFulfillPrim1.js:3:9:5:3) creates promise p0
*** promise p0 RESOLVED with value 1 at (MultipleFulfillPrim1.js:4:5:4:17)
*** return from call to Promise() constructor at (MultipleFulfillPrim1.js:3:9:5:3) associates OID obj3 with promise p0
*** call to Promise() constructor at (MultipleFulfillPrim1.js:7:10:9:3) creates promise p1
*** promise p1 REJECTED with value 1 at (MultipleFulfillPrim1.js:8:5:8:16)
*** return from call to Promise() constructor at (MultipleFulfillPrim1.js:7:10:9:3) associates OID obj5 with promise p1
SCRIPT EXIT (MultipleFulfillPrim1.js:1:1:9:4)
** endExecution for unit-test
