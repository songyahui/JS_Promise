
SCRIPT ENTER (SharedReaction.js:1:1:7:95) SharedReaction_jalangi_.js SharedReaction.js
*** call to Promise.resolve() at (SharedReaction.js:1:10:1:29) creates promise p0
*** return from call to Promise.resolve() at (SharedReaction.js:1:10:1:29) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 17 at (SharedReaction.js:1:10:1:29)
*** resolve identity  registered at (SharedReaction.js:7:1:7:27) on p0
*** reject identity  registered at (SharedReaction.js:7:1:7:27) on p0
*** call to then() on promise p0 at (SharedReaction.js:7:1:7:27) creates promise p1
*** resolve identity  registered at (SharedReaction.js:7:1:7:51) on p1
*** reject identity  registered at (SharedReaction.js:7:1:7:51) on p1
*** call to then() on promise p1 at (SharedReaction.js:7:1:7:51) creates promise p2
*** resolve identity  registered at (SharedReaction.js:7:1:7:75) on p2
*** reject identity  registered at (SharedReaction.js:7:1:7:75) on p2
*** call to then() on promise p2 at (SharedReaction.js:7:1:7:75) creates promise p3
*** resolve identity  registered at (SharedReaction.js:7:1:7:94) on p3
*** reject identity  registered at (SharedReaction.js:7:1:7:94) on p3
*** call to then() on promise p3 at (SharedReaction.js:7:1:7:94) creates promise p4
SCRIPT EXIT (SharedReaction.js:1:1:7:95)
*** function  returned value 17 at (SharedReaction.js:7:1:7:27)
*** promise p1 RESOLVED with explicitly returned value 17 at (SharedReaction.js:7:1:7:27)
*** function  returned value 17 at (SharedReaction.js:7:1:7:51)
*** promise p2 RESOLVED with explicitly returned value 17 at (SharedReaction.js:7:1:7:51)
*** function  returned value 17 at (SharedReaction.js:7:1:7:75)
*** promise p3 RESOLVED with explicitly returned value 17 at (SharedReaction.js:7:1:7:75)
*** function  returned value undefined at (SharedReaction.js:7:1:7:94)
*** promise p4 RESOLVED with implicitly returned value undefined at (SharedReaction.js:7:1:7:94)
** endExecution for unit-test
