
SCRIPT ENTER (SharedReactionFunction.js:1:1:6:30) SharedReactionFunction_jalangi_.js SharedReactionFunction.js
*** call to Promise.resolve() at (SharedReactionFunction.js:5:1:5:19) creates promise p0
*** return from call to Promise.resolve() at (SharedReactionFunction.js:5:1:5:19) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 1 at (SharedReactionFunction.js:5:1:5:19)
*** resolve identity foo registered at (SharedReactionFunction.js:5:1:5:29) on p0
*** reject identity _default registered at (SharedReactionFunction.js:5:1:5:29) on p0
*** call to then() on promise p0 at (SharedReactionFunction.js:5:1:5:29) creates promise p1
*** call to Promise.resolve() at (SharedReactionFunction.js:6:1:6:19) creates promise p2
*** return from call to Promise.resolve() at (SharedReactionFunction.js:6:1:6:19) associates OID obj11 with promise p2
*** promise p2 RESOLVED with value 2 at (SharedReactionFunction.js:6:1:6:19)
*** resolve identity foo registered at (SharedReactionFunction.js:6:1:6:29) on p2
*** reject identity _default registered at (SharedReactionFunction.js:6:1:6:29) on p2
*** call to then() on promise p2 at (SharedReactionFunction.js:6:1:6:29) creates promise p3
SCRIPT EXIT (SharedReactionFunction.js:1:1:6:30)
*** function foo returned value undefined at (SharedReactionFunction.js:5:1:5:29)
*** promise p1 RESOLVED with implicitly returned value undefined at (SharedReactionFunction.js:5:1:5:29)
*** function foo returned value undefined at (SharedReactionFunction.js:6:1:6:29)
*** promise p3 RESOLVED with implicitly returned value undefined at (SharedReactionFunction.js:6:1:6:29)
** endExecution for unit-test
