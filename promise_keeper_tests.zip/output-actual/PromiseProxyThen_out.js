
SCRIPT ENTER (PromiseProxyThen.js:1:1:14:1) PromiseProxyThen_jalangi_.js PromiseProxyThen.js
*** call to Promise.resolve() at (PromiseProxyThen.js:1:14:1:33) creates promise p0
*** return from call to Promise.resolve() at (PromiseProxyThen.js:1:14:1:33) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 42 at (PromiseProxyThen.js:1:14:1:33)
*** call to Proxy on promise p0 at (PromiseProxyThen.js:10:13:10:43) creates promise p1
*** resolve identity  registered at (PromiseProxyThen.js:11:9:13:3) on p1
*** reject identity _default registered at (PromiseProxyThen.js:11:9:13:3) on p1
*** call to then() on promise p1 at (PromiseProxyThen.js:11:9:13:3) creates promise p2
SCRIPT EXIT (PromiseProxyThen.js:1:1:14:1)
*** function  returned value undefined at (PromiseProxyThen.js:11:9:13:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (PromiseProxyThen.js:11:9:13:3)
** endExecution for unit-test
