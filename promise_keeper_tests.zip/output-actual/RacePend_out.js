
SCRIPT ENTER (RacePend.js:1:1:9:4) RacePend_jalangi_.js RacePend.js
*** call to race() on array [] at (RacePend.js:1:9:1:25) creates promise p0
*** resolve identity  registered at (RacePend.js:3:10:9:3) on p0
*** reject identity  registered at (RacePend.js:3:10:9:3) on p0
*** call to then() on promise p0 at (RacePend.js:3:10:9:3) creates promise p1
SCRIPT EXIT (RacePend.js:1:1:9:4)
** endExecution for unit-test
