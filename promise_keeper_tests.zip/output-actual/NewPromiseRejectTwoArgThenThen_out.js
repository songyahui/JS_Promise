
SCRIPT ENTER (NewPromiseRejectTwoArgThenThen.js:1:1:13:3) NewPromiseRejectTwoArgThenThen_jalangi_.js NewPromiseRejectTwoArgThenThen.js
*** call to Promise() constructor at (NewPromiseRejectTwoArgThenThen.js:3:9:3:62) creates promise p0
*** promise p0 REJECTED with value 42 at (NewPromiseRejectTwoArgThenThen.js:3:49:3:59)
*** return from call to Promise() constructor at (NewPromiseRejectTwoArgThenThen.js:3:9:3:62) associates OID obj3 with promise p0
*** resolve identity f1 registered at (NewPromiseRejectTwoArgThenThen.js:4:10:10:3) on p0
*** reject identity f2 registered at (NewPromiseRejectTwoArgThenThen.js:4:10:10:3) on p0
*** call to then() on promise p0 at (NewPromiseRejectTwoArgThenThen.js:4:10:10:3) creates promise p1
*** resolve identity f3 registered at (NewPromiseRejectTwoArgThenThen.js:11:10:13:3) on p1
*** reject identity _default registered at (NewPromiseRejectTwoArgThenThen.js:11:10:13:3) on p1
*** call to then() on promise p1 at (NewPromiseRejectTwoArgThenThen.js:11:10:13:3) creates promise p2
SCRIPT EXIT (NewPromiseRejectTwoArgThenThen.js:1:1:13:3)
*** function f2 returned value 17 at (NewPromiseRejectTwoArgThenThen.js:4:10:10:3)
*** promise p1 RESOLVED with explicitly returned value 17 at (NewPromiseRejectTwoArgThenThen.js:4:10:10:3)
*** function f3 returned value undefined at (NewPromiseRejectTwoArgThenThen.js:11:10:13:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (NewPromiseRejectTwoArgThenThen.js:11:10:13:3)
** endExecution for unit-test
