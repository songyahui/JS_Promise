
SCRIPT ENTER (BugDeadPromise1.js:1:1:11:1) BugDeadPromise1_jalangi_.js BugDeadPromise1.js
*** call to Promise() constructor at (BugDeadPromise1.js:2:10:4:3) creates promise p0
*** return from call to Promise() constructor at (BugDeadPromise1.js:2:10:4:3) associates OID obj3 with promise p0
*** resolve identity  registered at (BugDeadPromise1.js:6:10:10:3) on p0
*** reject identity _default registered at (BugDeadPromise1.js:6:10:10:3) on p0
*** call to then() on promise p0 at (BugDeadPromise1.js:6:10:10:3) creates promise p1
SCRIPT EXIT (BugDeadPromise1.js:1:1:11:1)
** endExecution for unit-test
