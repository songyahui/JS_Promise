
SCRIPT ENTER (ReturnNewBluebirdPromise.js:1:1:12:1) ReturnNewBluebirdPromise_jalangi_.js ReturnNewBluebirdPromise.js
*** call to Promise() constructor at (ReturnNewBluebirdPromise.js:5:12:8:7) creates promise p0
*** promise p0 RESOLVED with value undefined at (ReturnNewBluebirdPromise.js:7:9:7:18)
*** return from call to Promise() constructor at (ReturnNewBluebirdPromise.js:5:12:8:7) associates OID obj3 with promise p0
SCRIPT EXIT (ReturnNewBluebirdPromise.js:1:1:12:1)
** endExecution for unit-test
