
SCRIPT ENTER (NewPromiseBranchingThens1.js:1:1:11:4) NewPromiseBranchingThens1_jalangi_.js NewPromiseBranchingThens1.js
*** call to Promise() constructor at (NewPromiseBranchingThens1.js:3:9:3:63) creates promise p0
*** promise p0 RESOLVED with value 42 at (NewPromiseBranchingThens1.js:3:48:3:59)
*** return from call to Promise() constructor at (NewPromiseBranchingThens1.js:3:9:3:63) associates OID obj3 with promise p0
*** resolve identity f2 registered at (NewPromiseBranchingThens1.js:4:10:7:3) on p0
*** reject identity _default registered at (NewPromiseBranchingThens1.js:4:10:7:3) on p0
*** call to then() on promise p0 at (NewPromiseBranchingThens1.js:4:10:7:3) creates promise p1
*** resolve identity f3 registered at (NewPromiseBranchingThens1.js:8:10:11:3) on p0
*** reject identity _default registered at (NewPromiseBranchingThens1.js:8:10:11:3) on p0
*** call to then() on promise p0 at (NewPromiseBranchingThens1.js:8:10:11:3) creates promise p2
SCRIPT EXIT (NewPromiseBranchingThens1.js:1:1:11:4)
*** function f2 returned value 43 at (NewPromiseBranchingThens1.js:4:10:7:3)
*** promise p1 RESOLVED with explicitly returned value 43 at (NewPromiseBranchingThens1.js:4:10:7:3)
*** function f3 returned value 41 at (NewPromiseBranchingThens1.js:8:10:11:3)
*** promise p2 RESOLVED with explicitly returned value 41 at (NewPromiseBranchingThens1.js:8:10:11:3)
** endExecution for unit-test
