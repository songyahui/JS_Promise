
SCRIPT ENTER (AllAsyncResolve.js:1:1:18:55) AllAsyncResolve_jalangi_.js AllAsyncResolve.js
*** call to Promise.resolve() at (AllAsyncResolve.js:3:30:3:49) creates promise p0
*** return from call to Promise.resolve() at (AllAsyncResolve.js:3:30:3:49) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 33 at (AllAsyncResolve.js:3:30:3:49)
*** call to Promise.resolve() at (AllAsyncResolve.js:3:51:3:70) creates promise p1
*** return from call to Promise.resolve() at (AllAsyncResolve.js:3:51:3:70) associates OID obj5 with promise p1
*** promise p1 RESOLVED with value 44 at (AllAsyncResolve.js:3:51:3:70)
*** call to all() on array [p0,p1] at (AllAsyncResolve.js:5:9:5:43) creates promise p2
SCRIPT EXIT (AllAsyncResolve.js:1:1:18:55)
** endExecution for unit-test
