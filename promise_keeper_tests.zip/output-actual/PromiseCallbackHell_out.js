
SCRIPT ENTER (PromiseCallbackHell.js:1:1:21:2) PromiseCallbackHell_jalangi_.js PromiseCallbackHell.js
*** call to Promise.resolve() at (PromiseCallbackHell.js:12:12:12:30) creates promise p0
*** return from call to Promise.resolve() at (PromiseCallbackHell.js:12:12:12:30) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 1 at (PromiseCallbackHell.js:12:12:12:30)
*** resolve identity  registered at (PromiseCallbackHell.js:2:1:9:3) on p0
*** reject identity _default registered at (PromiseCallbackHell.js:2:1:9:3) on p0
*** call to then() on promise p0 at (PromiseCallbackHell.js:2:1:9:3) creates promise p1
SCRIPT EXIT (PromiseCallbackHell.js:1:1:21:2)
*** call to Promise.resolve() at (PromiseCallbackHell.js:16:12:16:30) creates promise p2
*** return from call to Promise.resolve() at (PromiseCallbackHell.js:16:12:16:30) associates OID obj11 with promise p2
*** promise p2 RESOLVED with value 2 at (PromiseCallbackHell.js:16:12:16:30)
*** resolve identity  registered at (PromiseCallbackHell.js:4:5:8:7) on p2
*** reject identity _default registered at (PromiseCallbackHell.js:4:5:8:7) on p2
*** call to then() on promise p2 at (PromiseCallbackHell.js:4:5:8:7) creates promise p3
*** function  returned value undefined at (PromiseCallbackHell.js:2:1:9:3)
*** promise p1 RESOLVED with implicitly returned value undefined at (PromiseCallbackHell.js:2:1:9:3)
*** call to Promise.resolve() at (PromiseCallbackHell.js:20:12:20:30) creates promise p4
*** return from call to Promise.resolve() at (PromiseCallbackHell.js:20:12:20:30) associates OID obj19 with promise p4
*** promise p4 RESOLVED with value 3 at (PromiseCallbackHell.js:20:12:20:30)
*** resolve identity  registered at (PromiseCallbackHell.js:5:9:7:11) on p4
*** reject identity _default registered at (PromiseCallbackHell.js:5:9:7:11) on p4
*** call to then() on promise p4 at (PromiseCallbackHell.js:5:9:7:11) creates promise p5
*** function  returned value undefined at (PromiseCallbackHell.js:4:5:8:7)
*** promise p3 RESOLVED with implicitly returned value undefined at (PromiseCallbackHell.js:4:5:8:7)
*** function  returned value undefined at (PromiseCallbackHell.js:5:9:7:11)
*** promise p5 RESOLVED with implicitly returned value undefined at (PromiseCallbackHell.js:5:9:7:11)
** endExecution for unit-test
