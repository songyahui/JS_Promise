
SCRIPT ENTER (NewPromiseImmediateResolve.js:1:1:3:64) NewPromiseImmediateResolve_jalangi_.js NewPromiseImmediateResolve.js
*** call to Promise() constructor at (NewPromiseImmediateResolve.js:3:9:3:63) creates promise p0
*** promise p0 RESOLVED with value 42 at (NewPromiseImmediateResolve.js:3:49:3:60)
*** return from call to Promise() constructor at (NewPromiseImmediateResolve.js:3:9:3:63) associates OID obj3 with promise p0
SCRIPT EXIT (NewPromiseImmediateResolve.js:1:1:3:64)
** endExecution for unit-test
