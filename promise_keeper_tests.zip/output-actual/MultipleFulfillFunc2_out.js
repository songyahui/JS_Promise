
SCRIPT ENTER (MultipleFulfillFunc2.js:1:1:15:4) MultipleFulfillFunc2_jalangi_.js MultipleFulfillFunc2.js
*** call to Promise() constructor at (MultipleFulfillFunc2.js:7:9:9:3) creates promise p0
*** promise p0 RESOLVED with value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(57, arguments.callee, this, arguments);
                            arguments = J$.N(65, 'arguments', arguments, 4);
                            return J$.X1(49, J$.Rt(41, J$.T(33, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(369, J$e);
                        } finally {
                            if (J$.Fr(377))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (MultipleFulfillFunc2.js:8:5:8:17)
*** return from call to Promise() constructor at (MultipleFulfillFunc2.js:7:9:9:3) associates OID obj5 with promise p0
*** call to Promise() constructor at (MultipleFulfillFunc2.js:13:10:15:3) creates promise p1
*** promise p1 REJECTED with value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(57, arguments.callee, this, arguments);
                            arguments = J$.N(65, 'arguments', arguments, 4);
                            return J$.X1(49, J$.Rt(41, J$.T(33, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(369, J$e);
                        } finally {
                            if (J$.Fr(377))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (MultipleFulfillFunc2.js:14:5:14:16)
*** return from call to Promise() constructor at (MultipleFulfillFunc2.js:13:10:15:3) associates OID obj7 with promise p1
SCRIPT EXIT (MultipleFulfillFunc2.js:1:1:15:4)
** endExecution for unit-test
