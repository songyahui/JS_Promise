
SCRIPT ENTER (PromiseReturnFunAsync1.js:1:1:14:4) PromiseReturnFunAsync1_jalangi_.js PromiseReturnFunAsync1.js
*** call to Promise() constructor at (PromiseReturnFunAsync1.js:7:9:9:3) creates promise p0
*** return from call to Promise() constructor at (PromiseReturnFunAsync1.js:7:9:9:3) associates OID obj3 with promise p0
*** resolve identity  registered at (PromiseReturnFunAsync1.js:11:1:14:3) on p0
*** reject identity _default registered at (PromiseReturnFunAsync1.js:11:1:14:3) on p0
*** call to then() on promise p0 at (PromiseReturnFunAsync1.js:11:1:14:3) creates promise p1
SCRIPT EXIT (PromiseReturnFunAsync1.js:1:1:14:4)
*** function  returned value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(337, J$e);
                        } finally {
                            if (J$.Fr(345))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (PromiseReturnFunAsync1.js:8:5:8:35)
*** promise p0 RESOLVED with value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(337, J$e);
                        } finally {
                            if (J$.Fr(345))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (PromiseReturnFunAsync1.js:8:5:8:35)
*** function  returned value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(337, J$e);
                        } finally {
                            if (J$.Fr(345))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (PromiseReturnFunAsync1.js:11:1:14:3)
*** promise p1 RESOLVED with explicitly returned value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(337, J$e);
                        } finally {
                            if (J$.Fr(345))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (PromiseReturnFunAsync1.js:11:1:14:3)
** endExecution for unit-test
