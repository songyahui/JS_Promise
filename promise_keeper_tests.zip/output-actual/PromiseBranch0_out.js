
SCRIPT ENTER (PromiseBranch0.js:1:1:22:1) PromiseBranch0_jalangi_.js PromiseBranch0.js
*** call to Promise.resolve() at (PromiseBranch0.js:18:17:18:36) creates promise p0
*** return from call to Promise.resolve() at (PromiseBranch0.js:18:17:18:36) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 42 at (PromiseBranch0.js:18:17:18:36)
*** call to Proxy on promise p0 at (PromiseBranch0.js:13:17:13:47) creates promise p1
*** resolve identity  registered at (PromiseBranch0.js:18:10:21:3) on p1
*** reject identity _default registered at (PromiseBranch0.js:18:10:21:3) on p1
*** call to then() on promise p1 at (PromiseBranch0.js:18:10:21:3) creates promise p2
SCRIPT EXIT (PromiseBranch0.js:1:1:22:1)
*** function  returned value 43 at (PromiseBranch0.js:18:10:21:3)
*** promise p2 RESOLVED with explicitly returned value 43 at (PromiseBranch0.js:18:10:21:3)
** endExecution for unit-test
