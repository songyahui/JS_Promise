
SCRIPT ENTER (PromiseReturnObjReject.js:1:1:9:1) PromiseReturnObjReject_jalangi_.js PromiseReturnObjReject.js
*** call to Promise() constructor at (PromiseReturnObjReject.js:8:9:8:63) creates promise p0
*** promise p0 REJECTED with value [object Object] at (PromiseReturnObjReject.js:8:49:8:60)
*** return from call to Promise() constructor at (PromiseReturnObjReject.js:8:9:8:63) associates OID obj5 with promise p0
SCRIPT EXIT (PromiseReturnObjReject.js:1:1:9:1)
** endExecution for unit-test
