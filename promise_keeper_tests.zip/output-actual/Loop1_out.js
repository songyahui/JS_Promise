
SCRIPT ENTER (Loop1.js:1:1:17:4) Loop1_jalangi_.js Loop1.js
*** call to Promise.resolve() at (Loop1.js:5:23:5:41) creates promise p0
*** return from call to Promise.resolve() at (Loop1.js:5:23:5:41) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 0 at (Loop1.js:5:23:5:41)
*** call to Promise.reject() at (Loop1.js:7:23:7:40) creates promise p1
*** return from call to Promise.reject() at (Loop1.js:7:23:7:40) associates OID obj5 with promise p1
*** promise p1 REJECTED with value 1 at (Loop1.js:7:23:7:40)
*** call to Promise.resolve() at (Loop1.js:5:23:5:41) creates promise p2
*** return from call to Promise.resolve() at (Loop1.js:5:23:5:41) associates OID obj7 with promise p2
*** promise p2 RESOLVED with value 2 at (Loop1.js:5:23:5:41)
*** call to Promise.reject() at (Loop1.js:7:23:7:40) creates promise p3
*** return from call to Promise.reject() at (Loop1.js:7:23:7:40) associates OID obj9 with promise p3
*** promise p3 REJECTED with value 3 at (Loop1.js:7:23:7:40)
*** call to Promise.resolve() at (Loop1.js:5:23:5:41) creates promise p4
*** return from call to Promise.resolve() at (Loop1.js:5:23:5:41) associates OID obj11 with promise p4
*** promise p4 RESOLVED with value 4 at (Loop1.js:5:23:5:41)
*** call to Promise.reject() at (Loop1.js:7:23:7:40) creates promise p5
*** return from call to Promise.reject() at (Loop1.js:7:23:7:40) associates OID obj13 with promise p5
*** promise p5 REJECTED with value 5 at (Loop1.js:7:23:7:40)
*** call to Promise.resolve() at (Loop1.js:5:23:5:41) creates promise p6
*** return from call to Promise.resolve() at (Loop1.js:5:23:5:41) associates OID obj15 with promise p6
*** promise p6 RESOLVED with value 6 at (Loop1.js:5:23:5:41)
*** call to Promise.reject() at (Loop1.js:7:23:7:40) creates promise p7
*** return from call to Promise.reject() at (Loop1.js:7:23:7:40) associates OID obj17 with promise p7
*** promise p7 REJECTED with value 7 at (Loop1.js:7:23:7:40)
*** call to Promise.resolve() at (Loop1.js:5:23:5:41) creates promise p8
*** return from call to Promise.resolve() at (Loop1.js:5:23:5:41) associates OID obj19 with promise p8
*** promise p8 RESOLVED with value 8 at (Loop1.js:5:23:5:41)
*** call to Promise.reject() at (Loop1.js:7:23:7:40) creates promise p9
*** return from call to Promise.reject() at (Loop1.js:7:23:7:40) associates OID obj21 with promise p9
*** promise p9 REJECTED with value 9 at (Loop1.js:7:23:7:40)
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p0
*** reject identity  registered at (Loop1.js:12:5:16:7) on p0
*** call to then() on promise p0 at (Loop1.js:12:5:16:7) creates promise p10
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p1
*** reject identity  registered at (Loop1.js:12:5:16:7) on p1
*** call to then() on promise p1 at (Loop1.js:12:5:16:7) creates promise p11
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p2
*** reject identity  registered at (Loop1.js:12:5:16:7) on p2
*** call to then() on promise p2 at (Loop1.js:12:5:16:7) creates promise p12
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p3
*** reject identity  registered at (Loop1.js:12:5:16:7) on p3
*** call to then() on promise p3 at (Loop1.js:12:5:16:7) creates promise p13
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p4
*** reject identity  registered at (Loop1.js:12:5:16:7) on p4
*** call to then() on promise p4 at (Loop1.js:12:5:16:7) creates promise p14
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p5
*** reject identity  registered at (Loop1.js:12:5:16:7) on p5
*** call to then() on promise p5 at (Loop1.js:12:5:16:7) creates promise p15
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p6
*** reject identity  registered at (Loop1.js:12:5:16:7) on p6
*** call to then() on promise p6 at (Loop1.js:12:5:16:7) creates promise p16
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p7
*** reject identity  registered at (Loop1.js:12:5:16:7) on p7
*** call to then() on promise p7 at (Loop1.js:12:5:16:7) creates promise p17
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p8
*** reject identity  registered at (Loop1.js:12:5:16:7) on p8
*** call to then() on promise p8 at (Loop1.js:12:5:16:7) creates promise p18
*** resolve identity  registered at (Loop1.js:12:5:16:7) on p9
*** reject identity  registered at (Loop1.js:12:5:16:7) on p9
*** call to then() on promise p9 at (Loop1.js:12:5:16:7) creates promise p19
SCRIPT EXIT (Loop1.js:1:1:17:4)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p10 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p11 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p12 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p13 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p14 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p15 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p16 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p17 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p18 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
*** function  returned value undefined at (Loop1.js:12:5:16:7)
*** promise p19 RESOLVED with implicitly returned value undefined at (Loop1.js:12:5:16:7)
** endExecution for unit-test
