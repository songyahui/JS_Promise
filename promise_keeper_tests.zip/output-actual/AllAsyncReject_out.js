
SCRIPT ENTER (AllAsyncReject.js:1:1:12:49) AllAsyncReject_jalangi_.js AllAsyncReject.js
*** call to Promise.resolve() at (AllAsyncReject.js:1:27:1:46) creates promise p0
*** return from call to Promise.resolve() at (AllAsyncReject.js:1:27:1:46) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 33 at (AllAsyncReject.js:1:27:1:46)
*** call to Promise.reject() at (AllAsyncReject.js:1:48:1:66) creates promise p1
*** return from call to Promise.reject() at (AllAsyncReject.js:1:48:1:66) associates OID obj5 with promise p1
*** promise p1 REJECTED with value 44 at (AllAsyncReject.js:1:48:1:66)
*** call to all() on array [p0,p1] at (AllAsyncReject.js:2:9:2:40) creates promise p2
SCRIPT EXIT (AllAsyncReject.js:1:1:12:49)
** endExecution for unit-test
