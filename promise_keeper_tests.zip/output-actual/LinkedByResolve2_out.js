
SCRIPT ENTER (LinkedByResolve2.js:1:1:12:1) LinkedByResolve2_jalangi_.js LinkedByResolve2.js
*** call to Promise.resolve() at (LinkedByResolve2.js:2:10:4:4) creates promise p0
*** return from call to Promise.resolve() at (LinkedByResolve2.js:2:10:4:4) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value undefined at (LinkedByResolve2.js:2:10:4:4)
*** call to Promise() constructor at (LinkedByResolve2.js:5:10:8:3) creates promise p1
*** return from call to Promise() constructor at (LinkedByResolve2.js:5:10:8:3) associates OID obj5 with promise p1
*** resolve identity  registered at (LinkedByResolve2.js:9:1:9:40) on p1
*** reject identity _default registered at (LinkedByResolve2.js:9:1:9:40) on p1
*** call to then() on promise p1 at (LinkedByResolve2.js:9:1:9:40) creates promise p2
SCRIPT EXIT (LinkedByResolve2.js:1:1:12:1)
** endExecution for unit-test
