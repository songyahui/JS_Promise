
SCRIPT ENTER (NewPromiseResolveAsync.js:1:1:10:4) NewPromiseResolveAsync_jalangi_.js NewPromiseResolveAsync.js
*** call to Promise() constructor at (NewPromiseResolveAsync.js:3:9:5:3) creates promise p0
*** return from call to Promise() constructor at (NewPromiseResolveAsync.js:3:9:5:3) associates OID obj3 with promise p0
*** resolve identity  registered at (NewPromiseResolveAsync.js:7:1:10:3) on p0
*** reject identity _default registered at (NewPromiseResolveAsync.js:7:1:10:3) on p0
*** call to then() on promise p0 at (NewPromiseResolveAsync.js:7:1:10:3) creates promise p1
SCRIPT EXIT (NewPromiseResolveAsync.js:1:1:10:4)
*** function  returned value foo at (NewPromiseResolveAsync.js:4:5:4:37)
*** promise p0 RESOLVED with value foo at (NewPromiseResolveAsync.js:4:5:4:37)
*** function  returned value foo at (NewPromiseResolveAsync.js:7:1:10:3)
*** promise p1 RESOLVED with explicitly returned value foo at (NewPromiseResolveAsync.js:7:1:10:3)
** endExecution for unit-test
