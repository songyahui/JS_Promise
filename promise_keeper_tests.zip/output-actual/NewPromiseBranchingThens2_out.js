
SCRIPT ENTER (NewPromiseBranchingThens2.js:1:1:9:4) NewPromiseBranchingThens2_jalangi_.js NewPromiseBranchingThens2.js
*** call to Promise() constructor at (NewPromiseBranchingThens2.js:3:9:3:63) creates promise p0
*** promise p0 RESOLVED with value 42 at (NewPromiseBranchingThens2.js:3:48:3:59)
*** return from call to Promise() constructor at (NewPromiseBranchingThens2.js:3:9:3:63) associates OID obj3 with promise p0
*** resolve identity f2 registered at (NewPromiseBranchingThens2.js:4:10:6:3) on p0
*** reject identity _default registered at (NewPromiseBranchingThens2.js:4:10:6:3) on p0
*** call to then() on promise p0 at (NewPromiseBranchingThens2.js:4:10:6:3) creates promise p1
*** resolve identity f3 registered at (NewPromiseBranchingThens2.js:7:10:9:3) on p0
*** reject identity _default registered at (NewPromiseBranchingThens2.js:7:10:9:3) on p0
*** call to then() on promise p0 at (NewPromiseBranchingThens2.js:7:10:9:3) creates promise p2
SCRIPT EXIT (NewPromiseBranchingThens2.js:1:1:9:4)
*** function f2 returned value undefined at (NewPromiseBranchingThens2.js:4:10:6:3)
*** promise p1 RESOLVED with implicitly returned value undefined at (NewPromiseBranchingThens2.js:4:10:6:3)
*** function f3 returned value undefined at (NewPromiseBranchingThens2.js:7:10:9:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (NewPromiseBranchingThens2.js:7:10:9:3)
** endExecution for unit-test
