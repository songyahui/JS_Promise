
SCRIPT ENTER (PromiseReturnArrResolve.js:1:1:5:65) PromiseReturnArrResolve_jalangi_.js PromiseReturnArrResolve.js
*** call to Promise() constructor at (PromiseReturnArrResolve.js:5:9:5:64) creates promise p0
*** promise p0 RESOLVED with value 0,1,2 at (PromiseReturnArrResolve.js:5:49:5:61)
*** return from call to Promise() constructor at (PromiseReturnArrResolve.js:5:9:5:64) associates OID obj5 with promise p0
SCRIPT EXIT (PromiseReturnArrResolve.js:1:1:5:65)
** endExecution for unit-test
