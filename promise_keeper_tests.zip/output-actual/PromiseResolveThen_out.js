
SCRIPT ENTER (PromiseResolveThen.js:1:1:7:4) PromiseResolveThen_jalangi_.js PromiseResolveThen.js
*** call to Promise.resolve() at (PromiseResolveThen.js:3:10:3:28) creates promise p0
*** return from call to Promise.resolve() at (PromiseResolveThen.js:3:10:3:28) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 3 at (PromiseResolveThen.js:3:10:3:28)
*** resolve identity  registered at (PromiseResolveThen.js:4:1:7:3) on p0
*** reject identity _default registered at (PromiseResolveThen.js:4:1:7:3) on p0
*** call to then() on promise p0 at (PromiseResolveThen.js:4:1:7:3) creates promise p1
SCRIPT EXIT (PromiseResolveThen.js:1:1:7:4)
*** function  returned value 4 at (PromiseResolveThen.js:4:1:7:3)
*** promise p1 RESOLVED with explicitly returned value 4 at (PromiseResolveThen.js:4:1:7:3)
** endExecution for unit-test
