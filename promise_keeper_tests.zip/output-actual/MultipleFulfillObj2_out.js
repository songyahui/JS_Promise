
SCRIPT ENTER (MultipleFulfillObj2.js:1:1:18:3) MultipleFulfillObj2_jalangi_.js MultipleFulfillObj2.js
*** call to Promise() constructor at (MultipleFulfillObj2.js:6:9:8:3) creates promise p0
*** promise p0 RESOLVED with value [object Object] at (MultipleFulfillObj2.js:7:5:7:17)
*** return from call to Promise() constructor at (MultipleFulfillObj2.js:6:9:8:3) associates OID obj5 with promise p0
*** resolve identity  registered at (MultipleFulfillObj2.js:12:10:18:3) on p0
*** reject identity  registered at (MultipleFulfillObj2.js:12:10:18:3) on p0
*** call to then() on promise p0 at (MultipleFulfillObj2.js:12:10:18:3) creates promise p1
SCRIPT EXIT (MultipleFulfillObj2.js:1:1:18:3)
*** function  returned value [object Object] at (MultipleFulfillObj2.js:12:10:18:3)
*** promise p1 RESOLVED with explicitly returned value [object Object] at (MultipleFulfillObj2.js:12:10:18:3)
** endExecution for unit-test
