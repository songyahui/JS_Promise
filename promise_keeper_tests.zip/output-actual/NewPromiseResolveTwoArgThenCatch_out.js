
SCRIPT ENTER (NewPromiseResolveTwoArgThenCatch.js:1:1:13:3) NewPromiseResolveTwoArgThenCatch_jalangi_.js NewPromiseResolveTwoArgThenCatch.js
*** call to Promise() constructor at (NewPromiseResolveTwoArgThenCatch.js:3:9:3:63) creates promise p0
*** promise p0 RESOLVED with value 42 at (NewPromiseResolveTwoArgThenCatch.js:3:49:3:60)
*** return from call to Promise() constructor at (NewPromiseResolveTwoArgThenCatch.js:3:9:3:63) associates OID obj3 with promise p0
*** resolve identity f1 registered at (NewPromiseResolveTwoArgThenCatch.js:4:10:10:3) on p0
*** reject identity f2 registered at (NewPromiseResolveTwoArgThenCatch.js:4:10:10:3) on p0
*** call to then() on promise p0 at (NewPromiseResolveTwoArgThenCatch.js:4:10:10:3) creates promise p1
*** resolve identity _default registered at (NewPromiseResolveTwoArgThenCatch.js:11:10:13:3) on p1
*** reject identity f3 registered at (NewPromiseResolveTwoArgThenCatch.js:11:10:13:3) on p1
*** call to catch() on promise p1 at (NewPromiseResolveTwoArgThenCatch.js:11:10:13:3) creates promise p2
SCRIPT EXIT (NewPromiseResolveTwoArgThenCatch.js:1:1:13:3)
*** function f1 returned value 84 at (NewPromiseResolveTwoArgThenCatch.js:4:10:10:3)
*** promise p1 RESOLVED with explicitly returned value 84 at (NewPromiseResolveTwoArgThenCatch.js:4:10:10:3)
*** function _default returned value 84 at (NewPromiseResolveTwoArgThenCatch.js:11:10:13:3)
*** promise p2 RESOLVED with explicitly returned value 84 at (NewPromiseResolveTwoArgThenCatch.js:11:10:13:3)
** endExecution for unit-test
