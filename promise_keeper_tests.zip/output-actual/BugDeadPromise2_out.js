
SCRIPT ENTER (BugDeadPromise2.js:1:1:18:1) BugDeadPromise2_jalangi_.js BugDeadPromise2.js
*** call to Promise() constructor at (BugDeadPromise2.js:2:10:4:3) creates promise p0
*** return from call to Promise() constructor at (BugDeadPromise2.js:2:10:4:3) associates OID obj3 with promise p0
*** resolve identity  registered at (BugDeadPromise2.js:6:10:10:3) on p0
*** reject identity _default registered at (BugDeadPromise2.js:6:10:10:3) on p0
*** call to then() on promise p0 at (BugDeadPromise2.js:6:10:10:3) creates promise p1
*** resolve identity  registered at (BugDeadPromise2.js:12:10:16:3) on p1
*** reject identity _default registered at (BugDeadPromise2.js:12:10:16:3) on p1
*** call to then() on promise p1 at (BugDeadPromise2.js:12:10:16:3) creates promise p2
SCRIPT EXIT (BugDeadPromise2.js:1:1:18:1)
** endExecution for unit-test
