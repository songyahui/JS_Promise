
SCRIPT ENTER (RacePrimitivesOnly.js:1:1:10:1) RacePrimitivesOnly_jalangi_.js RacePrimitivesOnly.js
*** call to race() on array [Number 1,Number 2,Number 3] at (RacePrimitivesOnly.js:1:9:1:32) creates promise p0
*** resolve identity  registered at (RacePrimitivesOnly.js:3:10:9:3) on p0
*** reject identity  registered at (RacePrimitivesOnly.js:3:10:9:3) on p0
*** call to then() on promise p0 at (RacePrimitivesOnly.js:3:10:9:3) creates promise p1
SCRIPT EXIT (RacePrimitivesOnly.js:1:1:10:1)
*** function  returned value 1 at (RacePrimitivesOnly.js:3:10:9:3)
*** promise p1 RESOLVED with explicitly returned value 1 at (RacePrimitivesOnly.js:3:10:9:3)
** endExecution for unit-test
