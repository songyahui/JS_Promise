
SCRIPT ENTER (PromiseReturnObjChain3.js:1:1:15:4) PromiseReturnObjChain3_jalangi_.js PromiseReturnObjChain3.js
*** call to Promise() constructor at (PromiseReturnObjChain3.js:8:9:8:64) creates promise p0
*** promise p0 RESOLVED with value [object Object] at (PromiseReturnObjChain3.js:8:49:8:61)
*** return from call to Promise() constructor at (PromiseReturnObjChain3.js:8:9:8:64) associates OID obj5 with promise p0
*** resolve identity f1 registered at (PromiseReturnObjChain3.js:9:10:12:3) on p0
*** reject identity _default registered at (PromiseReturnObjChain3.js:9:10:12:3) on p0
*** call to then() on promise p0 at (PromiseReturnObjChain3.js:9:10:12:3) creates promise p1
*** resolve identity _default registered at (PromiseReturnObjChain3.js:9:10:15:3) on p1
*** reject identity f2 registered at (PromiseReturnObjChain3.js:9:10:15:3) on p1
*** call to catch() on promise p1 at (PromiseReturnObjChain3.js:9:10:15:3) creates promise p2
SCRIPT EXIT (PromiseReturnObjChain3.js:1:1:15:4)
*** function f1 threw value [object Object] at (PromiseReturnObjChain3.js:9:10:12:3)
*** promise p1 REJECTED with value [object Object] at (PromiseReturnObjChain3.js:9:10:12:3)
*** function f2 returned value [object Object] at (PromiseReturnObjChain3.js:9:10:15:3)
*** promise p2 RESOLVED with explicitly returned value [object Object] at (PromiseReturnObjChain3.js:9:10:15:3)
** endExecution for unit-test
