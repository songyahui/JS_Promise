
SCRIPT ENTER (AllPendingFulfillment.js:1:1:10:4) AllPendingFulfillment_jalangi_.js AllPendingFulfillment.js
*** call to Promise.resolve() at (AllPendingFulfillment.js:1:10:1:28) creates promise p0
*** return from call to Promise.resolve() at (AllPendingFulfillment.js:1:10:1:28) associates OID obj3 with promise p0
*** promise p0 RESOLVED with value 3 at (AllPendingFulfillment.js:1:10:1:28)
*** call to Promise() constructor at (AllPendingFulfillment.js:3:10:3:50) creates promise p1
*** return from call to Promise() constructor at (AllPendingFulfillment.js:3:10:3:50) associates OID obj5 with promise p1
*** call to Promise() constructor at (AllPendingFulfillment.js:4:10:4:64) creates promise p2
*** promise p2 RESOLVED with value 17 at (AllPendingFulfillment.js:4:50:4:61)
*** return from call to Promise() constructor at (AllPendingFulfillment.js:4:10:4:64) associates OID obj7 with promise p2
*** call to all() on array [p0,1337,p1,p2] at (AllPendingFulfillment.js:6:1:6:30) creates promise p3
*** resolve identity  registered at (AllPendingFulfillment.js:6:1:8:3) on p3
*** reject identity _default registered at (AllPendingFulfillment.js:6:1:8:3) on p3
*** call to then() on promise p3 at (AllPendingFulfillment.js:6:1:8:3) creates promise p4
*** resolve identity _default registered at (AllPendingFulfillment.js:6:1:10:3) on p4
*** reject identity  registered at (AllPendingFulfillment.js:6:1:10:3) on p4
*** call to catch() on promise p4 at (AllPendingFulfillment.js:6:1:10:3) creates promise p5
SCRIPT EXIT (AllPendingFulfillment.js:1:1:10:4)
** endExecution for unit-test
