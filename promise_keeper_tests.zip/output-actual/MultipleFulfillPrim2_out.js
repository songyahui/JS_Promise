
SCRIPT ENTER (MultipleFulfillPrim2.js:1:1:11:4) MultipleFulfillPrim2_jalangi_.js MultipleFulfillPrim2.js
*** call to Promise() constructor at (MultipleFulfillPrim2.js:3:9:5:3) creates promise p0
*** promise p0 RESOLVED with value 1 at (MultipleFulfillPrim2.js:4:5:4:17)
*** return from call to Promise() constructor at (MultipleFulfillPrim2.js:3:9:5:3) associates OID obj3 with promise p0
*** call to Promise() constructor at (MultipleFulfillPrim2.js:9:10:11:3) creates promise p1
*** promise p1 REJECTED with value 2 at (MultipleFulfillPrim2.js:10:5:10:16)
*** return from call to Promise() constructor at (MultipleFulfillPrim2.js:9:10:11:3) associates OID obj5 with promise p1
SCRIPT EXIT (MultipleFulfillPrim2.js:1:1:11:4)
** endExecution for unit-test
