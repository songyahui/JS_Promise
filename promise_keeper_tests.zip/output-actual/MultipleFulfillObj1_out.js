
SCRIPT ENTER (MultipleFulfillObj1.js:1:1:12:4) MultipleFulfillObj1_jalangi_.js MultipleFulfillObj1.js
*** call to Promise() constructor at (MultipleFulfillObj1.js:6:9:8:3) creates promise p0
*** promise p0 RESOLVED with value [object Object] at (MultipleFulfillObj1.js:7:5:7:17)
*** return from call to Promise() constructor at (MultipleFulfillObj1.js:6:9:8:3) associates OID obj5 with promise p0
*** call to Promise() constructor at (MultipleFulfillObj1.js:10:10:12:3) creates promise p1
*** promise p1 REJECTED with value [object Object] at (MultipleFulfillObj1.js:11:5:11:16)
*** return from call to Promise() constructor at (MultipleFulfillObj1.js:10:10:12:3) associates OID obj7 with promise p1
SCRIPT EXIT (MultipleFulfillObj1.js:1:1:12:4)
** endExecution for unit-test
