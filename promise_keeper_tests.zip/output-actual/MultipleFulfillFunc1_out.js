
SCRIPT ENTER (MultipleFulfillFunc1.js:1:1:11:4) MultipleFulfillFunc1_jalangi_.js MultipleFulfillFunc1.js
*** call to Promise() constructor at (MultipleFulfillFunc1.js:5:9:7:3) creates promise p0
*** promise p0 RESOLVED with value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(313, J$e);
                        } finally {
                            if (J$.Fr(321))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (MultipleFulfillFunc1.js:6:5:6:17)
*** return from call to Promise() constructor at (MultipleFulfillFunc1.js:5:9:7:3) associates OID obj5 with promise p0
*** call to Promise() constructor at (MultipleFulfillFunc1.js:9:10:11:3) creates promise p1
*** promise p1 REJECTED with value function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(33, arguments.callee, this, arguments);
                            arguments = J$.N(41, 'arguments', arguments, 4);
                            return J$.X1(25, J$.Rt(17, J$.T(9, 1, 22, false)));
                        } catch (J$e) {
                            J$.Ex(313, J$e);
                        } finally {
                            if (J$.Fr(321))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            } at (MultipleFulfillFunc1.js:10:5:10:16)
*** return from call to Promise() constructor at (MultipleFulfillFunc1.js:9:10:11:3) associates OID obj7 with promise p1
SCRIPT EXIT (MultipleFulfillFunc1.js:1:1:11:4)
** endExecution for unit-test
