
SCRIPT ENTER (MissingExceptionalReject.js:1:1:10:160) MissingExceptionalReject_jalangi_.js MissingExceptionalReject.js
*** call to Promise() constructor at (MissingExceptionalReject.js:3:10:6:3) creates promise p0
*** promise p0 RESOLVED with value 42 at (MissingExceptionalReject.js:5:5:5:16)
*** return from call to Promise() constructor at (MissingExceptionalReject.js:3:10:6:3) associates OID obj3 with promise p0
*** resolve identity  registered at (MissingExceptionalReject.js:7:10:9:3) on p0
*** reject identity _default registered at (MissingExceptionalReject.js:7:10:9:3) on p0
*** call to then() on promise p0 at (MissingExceptionalReject.js:7:10:9:3) creates promise p1
SCRIPT EXIT (MissingExceptionalReject.js:1:1:10:160)
*** function  threw value Error: unhandled error at (MissingExceptionalReject.js:7:10:9:3)
*** promise p1 REJECTED with value Error: unhandled error at (MissingExceptionalReject.js:7:10:9:3)
** endExecution for unit-test
