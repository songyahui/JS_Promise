
SCRIPT ENTER (PromiseReturnObjResolve.js:1:1:8:65) PromiseReturnObjResolve_jalangi_.js PromiseReturnObjResolve.js
*** call to Promise() constructor at (PromiseReturnObjResolve.js:8:9:8:64) creates promise p0
*** promise p0 RESOLVED with value [object Object] at (PromiseReturnObjResolve.js:8:49:8:61)
*** return from call to Promise() constructor at (PromiseReturnObjResolve.js:8:9:8:64) associates OID obj5 with promise p0
SCRIPT EXIT (PromiseReturnObjResolve.js:1:1:8:65)
** endExecution for unit-test
