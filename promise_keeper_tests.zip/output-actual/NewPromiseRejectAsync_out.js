
SCRIPT ENTER (NewPromiseRejectAsync.js:1:1:13:4) NewPromiseRejectAsync_jalangi_.js NewPromiseRejectAsync.js
*** call to Promise() constructor at (NewPromiseRejectAsync.js:3:9:5:3) creates promise p0
*** return from call to Promise() constructor at (NewPromiseRejectAsync.js:3:9:5:3) associates OID obj3 with promise p0
*** resolve identity  registered at (NewPromiseRejectAsync.js:7:1:13:3) on p0
*** reject identity  registered at (NewPromiseRejectAsync.js:7:1:13:3) on p0
*** call to then() on promise p0 at (NewPromiseRejectAsync.js:7:1:13:3) creates promise p1
SCRIPT EXIT (NewPromiseRejectAsync.js:1:1:13:4)
*** function  returned value foo at (NewPromiseRejectAsync.js:4:5:4:36)
*** promise p0 REJECTED with value foo at (NewPromiseRejectAsync.js:4:5:4:36)
*** function  returned value foo at (NewPromiseRejectAsync.js:7:1:13:3)
*** promise p1 RESOLVED with explicitly returned value foo at (NewPromiseRejectAsync.js:7:1:13:3)
** endExecution for unit-test
