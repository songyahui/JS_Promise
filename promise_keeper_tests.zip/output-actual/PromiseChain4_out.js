
SCRIPT ENTER (PromiseChain4.js:1:1:9:3) PromiseChain4_jalangi_.js PromiseChain4.js
*** call to Promise() constructor at (PromiseChain4.js:3:9:3:63) creates promise p0
*** promise p0 RESOLVED with value 17 at (PromiseChain4.js:3:49:3:60)
*** return from call to Promise() constructor at (PromiseChain4.js:3:9:3:63) associates OID obj3 with promise p0
*** resolve identity f1 registered at (PromiseChain4.js:4:10:6:3) on p0
*** reject identity _default registered at (PromiseChain4.js:4:10:6:3) on p0
*** call to then() on promise p0 at (PromiseChain4.js:4:10:6:3) creates promise p1
*** resolve identity _default registered at (PromiseChain4.js:7:1:9:3) on p1
*** reject identity  registered at (PromiseChain4.js:7:1:9:3) on p1
*** call to catch() on promise p1 at (PromiseChain4.js:7:1:9:3) creates promise p2
SCRIPT EXIT (PromiseChain4.js:1:1:9:3)
*** function f1 threw value 77 at (PromiseChain4.js:4:10:6:3)
*** promise p1 REJECTED with value 77 at (PromiseChain4.js:4:10:6:3)
*** function  returned value undefined at (PromiseChain4.js:7:1:9:3)
*** promise p2 RESOLVED with implicitly returned value undefined at (PromiseChain4.js:7:1:9:3)
** endExecution for unit-test
